class user {
    constructor(id, email, password, username ) {
      this.id = id;
      this.email = email;
      this.password = password;
      this.username = username;
    }
  }
  
  module.exports = user;